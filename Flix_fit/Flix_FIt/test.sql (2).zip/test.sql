-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 23, 2023 at 04:55 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `calender`
--

CREATE TABLE `calender` (
  `Calender_id` tinyint(1) NOT NULL DEFAULT 0,
  `Booked_mon` tinyint(1) NOT NULL DEFAULT 0,
  `Monday` tinytext NOT NULL,
  `Tuesday` tinytext NOT NULL,
  `Booked_tue` tinytext NOT NULL DEFAULT '0',
  `Wednesday` tinytext NOT NULL,
  `Booked_wed` tinytext NOT NULL DEFAULT '\'0\'',
  `Thursday` tinytext NOT NULL,
  `Booked_thur` tinytext NOT NULL DEFAULT '0',
  `Friday` tinytext NOT NULL,
  `Booked_fri` tinytext NOT NULL DEFAULT '0',
  `Saturday` tinytext NOT NULL,
  `Booked_sat` tinytext NOT NULL DEFAULT '0',
  `Sunday` tinytext NOT NULL,
  `Booked_sun` tinytext NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `calender`
--

INSERT INTO `calender` (`Calender_id`, `Booked_mon`, `Monday`, `Tuesday`, `Booked_tue`, `Wednesday`, `Booked_wed`, `Thursday`, `Booked_thur`, `Friday`, `Booked_fri`, `Saturday`, `Booked_sat`, `Sunday`, `Booked_sun`) VALUES
(0, 0, '10-11am', '10-11am', '0', '10-11am', '0', '10-11am', '0', '10-11am', '0', '10-11am', '0', '10-11am', '0'),
(1, 0, '11-12pm', '11-12pm', '0', '11-12pm', '0', '11-12pm', '0', '11-12pm', '0', '11-12pm', '0', '11-12pm', '0');

-- --------------------------------------------------------

--
-- Table structure for table `session_test`
--

CREATE TABLE `session_test` (
  `session_id` int(11) NOT NULL,
  `Exercise_1` text NOT NULL,
  `Exercise_2` text NOT NULL,
  `Exercise_3` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `session_test`
--

INSERT INTO `session_test` (`session_id`, `Exercise_1`, `Exercise_2`, `Exercise_3`) VALUES
(0, 'Lat pull-downs', 'push-ups', 'shoulder press'),
(1, 'Sqauts', 'squat jumps ', 'lunges'),
(2, 'po-go hops', 'jumping jacks', 'skips');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id_users` int(11) NOT NULL,
  `name` tinytext NOT NULL,
  `pwd` longtext NOT NULL,
  `Admin` tinyint(1) NOT NULL DEFAULT 0,
  `Goals` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_users`, `name`, `pwd`, `Admin`, `Goals`) VALUES
(0, 'User_Admin', 'Password_Admin', 1, 'I will commit to a balanced routine that includes cardio, strength training, and flexibility exercises, aiming to improve my overall endurance, strength, and flexibility. I will prioritize consistency, dedicating at least five days a week to workouts and allowing for proper rest and recovery. Additionally, I\'ll focus on maintaining a nutritious diet, filled with whole foods and proper hydration. By incorporating mindfulness practices like meditation and yoga, I will enhance my mental resilience and reduce stress. My ultimate objective is to lead a healthy lifestyle, feeling energized, confident, and happy in my body.'),
(1, 'User_Costumer_1', 'Password_Costumer_1', 0, 'My fitness goal is to achieve a well-balanced and healthy lifestyle through consistent exercise, focusing on a variety of activities like strength training, cardio, and flexibility exercises. I aim to improve my overall fitness level, increase muscular strength and endurance, and enhance my cardiovascular health. Additionally, I strive to adopt a nutritious diet that supports my fitness journey, fueling my body with wholesome foods. My ultimate aim is to feel more energetic, confident, and capable in daily life, as well as to maintain a positive mindset throughout the entire fitness journey.'),
(3, 'User_Costumer_2', 'Password_Costumer_2', 0, 'I aim to cultivate a consistent exercise routine, incorporating strength training, cardiovascular activities, and flexibility exercises. By committing to regular workouts, I strive to build lean muscle, improve endurance, and increase flexibility. Alongside my fitness endeavors, I intend to adopt a balanced and nutritious diet, focusing on whole foods and portion control to fuel my body optimally. In this pursuit, I aspire to shed excess body fat, boost energy levels, and enhance my overall health and vitality. Through perseverance, dedication, and self-discipline, I am determined to embrace a lifestyle of enduring wellness.');

-- --------------------------------------------------------

--
-- Table structure for table `user_workout_result`
--

CREATE TABLE `user_workout_result` (
  `result_id` int(11) NOT NULL,
  `id_users` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `Exercise_1_rep` int(11) NOT NULL,
  `Exercise_1_weight` int(11) NOT NULL,
  `Exercise_2_rep` int(11) NOT NULL,
  `Exercise_2_weight` int(11) NOT NULL,
  `Exercise_3_rep` int(11) NOT NULL,
  `Exercise_3_weight` int(11) NOT NULL,
  `reflection_Q1` int(11) NOT NULL,
  `reflection_Q2` int(11) NOT NULL,
  `reflection_notes` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user_workout_result`
--

INSERT INTO `user_workout_result` (`result_id`, `id_users`, `session_id`, `Exercise_1_rep`, `Exercise_1_weight`, `Exercise_2_rep`, `Exercise_2_weight`, `Exercise_3_rep`, `Exercise_3_weight`, `reflection_Q1`, `reflection_Q2`, `reflection_notes`) VALUES
(0, 3, 2, 30, 30, 30, 30, 30, 30, 3, 3, 'Overall i did ok. I really hope this works'),
(36, 0, 1, 22, 22, 22, 22, 22, 22, 2, 3, 'hard workout '),
(37, 1, 0, 4, 0, 4, 0, 4, 0, 2, 2, 'My shoulder hurt really bad and I could not llift the weight anymore ');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `calender`
--
ALTER TABLE `calender`
  ADD PRIMARY KEY (`Calender_id`);

--
-- Indexes for table `session_test`
--
ALTER TABLE `session_test`
  ADD PRIMARY KEY (`session_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_users`);

--
-- Indexes for table `user_workout_result`
--
ALTER TABLE `user_workout_result`
  ADD PRIMARY KEY (`result_id`),
  ADD KEY `result_id` (`result_id`),
  ADD KEY `session_id` (`session_id`),
  ADD KEY `id_users` (`id_users`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_users` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user_workout_result`
--
ALTER TABLE `user_workout_result`
  MODIFY `result_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `user_workout_result`
--
ALTER TABLE `user_workout_result`
  ADD CONSTRAINT `user_workout_result_ibfk_1` FOREIGN KEY (`session_id`) REFERENCES `session_test` (`session_id`),
  ADD CONSTRAINT `user_workout_result_ibfk_2` FOREIGN KEY (`id_users`) REFERENCES `users` (`id_users`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
